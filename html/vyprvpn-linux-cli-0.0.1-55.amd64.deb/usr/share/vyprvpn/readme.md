# VyprVPN Linux Wrapper
This tool helps make working with a VyprVPN connection on Linux based systems more seamless. It consists of a serivce process that is managed by upstart or systemd and a command line interface for logging in and setting up NetworkManager VPN connections.

## Installation
sudo apt-get install gdebi
sudo gdebi package.deb

## How to use vyprvpn cli
Once the vyprvpn_service has been started via the included upstart script the following commands are available via the command line tool. By default the tool should be install to /usr/bin/vyprvpn and does not require elevated permissions to run. The vyprvpn_service will be installed to /usr/sbin/vyprvpn_service and does currently run as root.

## Command Line Help:
`vyprvpn --help`

## Bugs and TODOs
* Missing chameleon and ipsec
* Readme is not included in deb file
* vyprvpn command line context help missing
* man files
* Service state persistance across reboots
* Fix upstart script to start on boot properly
* Better error messaging
* Default protocol selection not completed
* Add x86 support deb
* RPM support + systemd init script creation

##Pre Requirements
### Ubuntu/Debian
network-manager
network-manager-pptp
network-manager-openvpn
network-manager-vpnc
vpnc

### RedHat/Fedora
TBA