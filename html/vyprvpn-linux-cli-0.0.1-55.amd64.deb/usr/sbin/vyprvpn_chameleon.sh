#!/bin/bash

echo "vyprvpn_chameleon -p $1 $2 $3"
nohup vyprvpn_chameleon -b -p $1 $2 $3 &
